create definer = root@localhost view product_view as
select `demo2006`.`product`.`id`         AS `id`,
       `demo2006`.`product`.`name`       AS `name`,
       `demo2006`.`product`.`price`      AS `price`,
       `demo2006`.`product`.`quantity`   AS `quantity`,
       `demo2006`.`product`.`idCategory` AS `idCategory`
from `demo2006`.`product`;

