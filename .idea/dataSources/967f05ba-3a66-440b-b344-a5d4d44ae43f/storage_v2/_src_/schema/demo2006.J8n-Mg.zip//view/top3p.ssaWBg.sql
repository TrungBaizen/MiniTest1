create definer = root@localhost view top3p as
select `demo2006`.`product`.`price` AS `price`
from `demo2006`.`product`
group by `demo2006`.`product`.`price`
order by `demo2006`.`product`.`price` desc
limit 3;

