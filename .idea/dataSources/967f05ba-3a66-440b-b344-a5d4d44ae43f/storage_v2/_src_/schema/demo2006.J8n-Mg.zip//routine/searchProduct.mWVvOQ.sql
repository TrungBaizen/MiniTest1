create
    definer = root@localhost procedure searchProduct(IN idCatagory int, OUT name varchar(50))
begin
    select product.name into name from product where idCategory = idCatagory;
end;

